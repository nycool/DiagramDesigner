# DiagramDesigner
Diagram designer from https://www.codeproject.com/Articles/24681/WPF-Diagram-Designer-Part-4
